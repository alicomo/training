<?php

class frontendConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
