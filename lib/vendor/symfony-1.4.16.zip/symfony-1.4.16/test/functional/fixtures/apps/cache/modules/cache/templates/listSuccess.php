<span id="page"><?php echo $page ?></span>
