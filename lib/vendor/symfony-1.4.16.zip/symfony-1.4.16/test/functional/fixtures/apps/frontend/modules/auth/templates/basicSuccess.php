<div id="user"><?php echo $auth_user ?></div>
<div id="password"><?php echo $auth_password ?></div>
<div id='msg'><?php echo $msg ?></div>
