<div><?php echo $o->getFoo() ?></div>
