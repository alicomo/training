<div id="anotherCacheablePartial"><?php include_partial('cache/anotherCacheablePartial') ?></div>
